# 瑞牧 · 暖米白

17种动画状态、五档尺寸。双击`安装鼠标主题.cmd`默认48px并打开指针方案页；双击`恢复原鼠标.cmd`恢复最初设置。高级尺寸：`powershell -NoProfile -ExecutionPolicy Bypass -File ./install-theme.ps1 -Size 96`。

预览与点击点：`preview.html`。原生素材检查通过；真实桌面与多屏体验需实测。

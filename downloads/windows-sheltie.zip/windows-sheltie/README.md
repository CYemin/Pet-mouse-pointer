# Windows 合集（7款）

完整解压后双击一键安装入口。默认32px，所有款式存为可选方案，最后一套生效。安装后打开鼠标属性的指针页选择方案。恢复原鼠标.cmd恢复首次安装前基线。安装器会先检查全部目标，再依次执行；中途失败停止并保留已完成项。`--check`只预演。

高级尺寸：powershell -NoProfile -ExecutionPolicy Bypass -File ./install-catalog.ps1 -Collection all -Size 96

# 边牧 Mousecape 测试合集

先安装官方Mousecape，双击.command批量导入，再在Mousecape选一套Apply。格式及像素转换已检查，Mac真机导入/应用、Retina和多屏待测。

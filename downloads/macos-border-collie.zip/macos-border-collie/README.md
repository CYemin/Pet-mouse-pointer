# 边牧 Mousecape 测试合集

先安装官方Mousecape，双击.command批量导入，再在Mousecape选一套Apply。格式及像素转换已检查，Mac真机导入/应用、Retina和多屏待测。


从旧版升级：先在Mousecape恢复默认并移除旧的同款主题，再重新导入新版.cape并Apply；无需移除其他品种。重复导入可能保留同名副本，请确认所选版本为2.0、共19个条目。仅下载或解压ZIP不会更新已导入主题。

#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./border-collie-black-white-v1/border-collie-black-white-v1-48pt.cape"
open -a Mousecape "./border-collie-brown-white-v1/border-collie-brown-white-v1-48pt.cape"
open -a Mousecape "./border-collie-blue-merle-v1/border-collie-blue-merle-v1-48pt.cape"
echo "Imported. Select a theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

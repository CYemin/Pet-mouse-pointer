@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "PET_CHECK="
if /i "%~1"=="--check" set "PET_CHECK=-WhatIf"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-catalog.ps1" -Collection westie -OpenPointerSettings %PET_CHECK%
set "PET_EXIT=%ERRORLEVEL%"
if not "%PET_EXIT%"=="0" if not defined PET_CHECK pause
exit /b %PET_EXIT%

#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./pet-pixel-complete/pet-pixel-complete-48pt.cape"
open -a Mousecape "./sheltie-dark-sable-pixel/sheltie-dark-sable-pixel-48pt.cape"
open -a Mousecape "./sheltie-tricolor-pixel/sheltie-tricolor-pixel-48pt.cape"
open -a Mousecape "./sheltie-blue-merle-pixel/sheltie-blue-merle-pixel-48pt.cape"
open -a Mousecape "./sheltie-red-merle-pixel/sheltie-red-merle-pixel-48pt.cape"
open -a Mousecape "./sheltie-bi-black-pixel/sheltie-bi-black-pixel-48pt.cape"
open -a Mousecape "./sheltie-bi-blue-pixel/sheltie-bi-blue-pixel-48pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

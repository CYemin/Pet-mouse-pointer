# macOS Mousecape 测试合集（7款）

先安装官方Mousecape，完整解压后双击`一键导入全部主题-32pt.command`（大号48pt）。也可双击各主题.cape逐一导入。随后在Mousecape选中一套、Apply；恢复使用Capes → Restore Defaults。脚本只导入，不自动应用或安装Mousecape。

导出格式及每个嵌入像素已验证；当前在Windows构建，Mac真机导入、应用、Retina和多屏均待测。详见macOS.md。


从旧版升级：先在Mousecape恢复默认并移除旧的同款主题，再重新导入新版.cape并Apply；无需移除其他品种。重复导入可能保留同名副本，请确认所选版本为2.0、共19个条目。仅下载或解压ZIP不会更新已导入主题。

#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./westie-profile-v1/westie-profile-v1-32pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

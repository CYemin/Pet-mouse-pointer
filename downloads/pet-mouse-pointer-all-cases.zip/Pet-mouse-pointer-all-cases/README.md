# 宠物鼠标指针 · 全部13套案例合集

11套像素全动画主题 + 手绘小狗（5动态/12静态）+ 黑猫抱箭头（17静态）。每套均有17角色和32/48/64/96/128px。

## 使用

1. 完整解压此ZIP，进入喜欢的主题文件夹。
2. 双击「应用鼠标主题.cmd」应用48px，或「应用大号鼠标.cmd」应用96px。
3. 双击「恢复原鼠标.cmd」恢复原设置；切换主题前请阅读各主题说明。
4. 打开每套 preview.html 查看动作、尺寸与点击点。无需Python。

合集包含指针、预览、提示词和验证记录；不含大型源精灵图及逐帧复查图/GIF；完整复查媒体可另取单套包。未附私人参考照片。

| 文件夹 | 案例 | 动画状态 |
|---|---|---|
| `pet-pixel-complete` | 雕色喜乐蒂 | 17/17 |
| `golden-cream-pixel` | 奶油白金毛 | 17/17 |
| `sheltie-tricolor-pixel` | 黑白三色喜乐蒂 | 17/17 |
| `sheltie-blue-merle-pixel` | 三色陨石喜乐蒂 | 17/17 |
| `golden-standard-pixel` | 标准金毛 | 17/17 |
| `golden-dark-pixel` | 深金毛 | 17/17 |
| `sheltie-dark-sable-pixel` | 深雕色喜乐蒂 | 17/17 |
| `sheltie-bi-black-pixel` | 黑白两色喜乐蒂 | 17/17 |
| `sheltie-bi-blue-pixel` | 蓝陨石色喜乐蒂 | 17/17 |
| `golden-light-pixel` | 浅金毛 | 17/17 |
| `sheltie-red-merle-pixel` | 红陨石喜乐蒂 | 17/17 |
| `pet-handdrawn-complete` | 手绘小狗 | 5/17 |
| `black-cat-hug` | 黑猫抱箭头 | 0/17 |

Windows原生格式、加载和热点检查通过。原生检查和预演未替换桌面鼠标；实际点击手感、多显示器和DPI切换仍需试用。
手绘旧案例未记录完整逐帧视觉验收，像素11套的视觉记录见各主题 motion-review/visual-review.json。
项目：https://github.com/CYemin/Pet-mouse-pointer

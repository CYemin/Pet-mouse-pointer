#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./pomeranian-orange-v1/pomeranian-orange-v1-32pt.cape"
open -a Mousecape "./pomeranian-cream-v1/pomeranian-cream-v1-32pt.cape"
open -a Mousecape "./pomeranian-black-tan-v1/pomeranian-black-tan-v1-32pt.cape"
echo "Imported. Select a theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

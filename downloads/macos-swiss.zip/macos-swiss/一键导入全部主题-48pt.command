#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./swiss-profile-v6/swiss-profile-v6-48pt.cape"
open -a Mousecape "./swiss-ivory-profile-v6/swiss-ivory-profile-v6-48pt.cape"
open -a Mousecape "./swiss-ice-profile-v6/swiss-ice-profile-v6-48pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

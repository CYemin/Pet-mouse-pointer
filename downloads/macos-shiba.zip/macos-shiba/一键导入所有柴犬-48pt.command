#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Install official Mousecape first."; exit 1; fi
open -a Mousecape "./shiba-white-v1/shiba-white-v1-48pt.cape"
open -a Mousecape "./shiba-red-v1/shiba-red-v1-48pt.cape"
open -a Mousecape "./shiba-black-tan-v1/shiba-black-tan-v1-48pt.cape"
open -a Mousecape "./shiba-sesame-v1/shiba-sesame-v1-48pt.cape"
echo "Imported. Select one theme and Apply in Mousecape."

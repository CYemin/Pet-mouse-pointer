# 柴犬 Mousecape 四款合集

先安装官方Mousecape。双击32pt或48pt导入入口，再选一套Apply。每套为2.0版，含19个条目，包括macOS26+ ArrowS/IBeamS别名。导入旧同款前先恢复默认并移除旧同款，避免重复副本。已核验全部嵌入图像、时序与热点；Mac真机、Retina、多屏待测。

#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./teddy-profile-v6/teddy-profile-v6-48pt.cape"
open -a Mousecape "./teddy-cream-profile-v6/teddy-cream-profile-v6-48pt.cape"
open -a Mousecape "./teddy-chocolate-profile-v6/teddy-chocolate-profile-v6-48pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

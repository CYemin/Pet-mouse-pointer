# 宠物鼠标 · macOS 测试版（11套）

**先读这个：双击 `.cape` 只是把主题「导入」Mousecape 列表，指针不会立即改变；必须在 Mousecape 里选中主题并点 `Apply` 才生效。**

完整步骤、常见问题和恢复方法见 [安装与恢复说明](macOS.md)。
Windows 版的一键安装 / 切换风格入口在 macOS 上不适用（机制不同，详见说明）。

## 主题列表

- [Pixel Companion · 像素宠物指针](pet-pixel-complete/README.md) · [动画预览](pet-pixel-complete/preview.html)
- [Cream Golden · 奶油金犬像素指针](golden-cream-pixel/README.md) · [动画预览](golden-cream-pixel/preview.html)
- [三色喜乐蒂 · 像素指针](sheltie-tricolor-pixel/README.md) · [动画预览](sheltie-tricolor-pixel/preview.html)
- [蓝陨喜乐蒂 · 像素指针](sheltie-blue-merle-pixel/README.md) · [动画预览](sheltie-blue-merle-pixel/preview.html)
- [标准金毛 · 像素指针](golden-standard-pixel/README.md) · [动画预览](golden-standard-pixel/preview.html)
- [深金毛 · 像素指针](golden-dark-pixel/README.md) · [动画预览](golden-dark-pixel/preview.html)
- [Dark Sable Sheltie Pixel](sheltie-dark-sable-pixel/README.md) · [动画预览](sheltie-dark-sable-pixel/preview.html)
- [Bi-black Sheltie Pixel](sheltie-bi-black-pixel/README.md) · [动画预览](sheltie-bi-black-pixel/preview.html)
- [Bi Blue Sheltie Pixel](sheltie-bi-blue-pixel/README.md) · [动画预览](sheltie-bi-blue-pixel/preview.html)
- [Light Golden · 浅金毛像素指针](golden-light-pixel/README.md) · [动画预览](golden-light-pixel/preview.html)
- [红陨石喜乐蒂 · 像素指针](sheltie-red-merle-pixel/README.md) · [动画预览](sheltie-red-merle-pixel/preview.html)

格式检查通过；Mac 导入、系统应用和实际点击体验尚待实测。


从旧版升级：先在Mousecape恢复默认并移除旧的同款主题，再重新导入新版.cape并Apply；无需移除其他品种。重复导入可能保留同名副本，请确认所选版本为2.0、共19个条目。仅下载或解压ZIP不会更新已导入主题。

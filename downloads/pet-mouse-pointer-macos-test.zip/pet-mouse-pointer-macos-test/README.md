# 宠物鼠标 · macOS 测试版（11套）

先阅读 [安装与恢复说明](macOS.md)，然后进入喜欢的主题文件夹。

- [Pixel Companion · 像素宠物指针](pet-pixel-complete/README.md) · [动画预览](pet-pixel-complete/preview.html)
- [Cream Golden · 奶油金犬像素指针](golden-cream-pixel/README.md) · [动画预览](golden-cream-pixel/preview.html)
- [三色喜乐蒂 · 像素指针](sheltie-tricolor-pixel/README.md) · [动画预览](sheltie-tricolor-pixel/preview.html)
- [蓝陨喜乐蒂 · 像素指针](sheltie-blue-merle-pixel/README.md) · [动画预览](sheltie-blue-merle-pixel/preview.html)
- [标准金毛 · 像素指针](golden-standard-pixel/README.md) · [动画预览](golden-standard-pixel/preview.html)
- [深金毛 · 像素指针](golden-dark-pixel/README.md) · [动画预览](golden-dark-pixel/preview.html)
- [Dark Sable Sheltie Pixel](sheltie-dark-sable-pixel/README.md) · [动画预览](sheltie-dark-sable-pixel/preview.html)
- [Bi-black Sheltie Pixel](sheltie-bi-black-pixel/README.md) · [动画预览](sheltie-bi-black-pixel/preview.html)
- [Bi Blue Sheltie Pixel](sheltie-bi-blue-pixel/README.md) · [动画预览](sheltie-bi-blue-pixel/preview.html)
- [Light Golden · 浅金毛像素指针](golden-light-pixel/README.md) · [动画预览](golden-light-pixel/preview.html)
- [红陨石喜乐蒂 · 像素指针](sheltie-red-merle-pixel/README.md) · [动画预览](sheltie-red-merle-pixel/preview.html)

格式检查通过，Mac导入、系统应用和实际点击体验尚待实测。

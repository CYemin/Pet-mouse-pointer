#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./husky-profile-v6/husky-profile-v6-48pt.cape"
open -a Mousecape "./husky-silver-profile-v6/husky-silver-profile-v6-48pt.cape"
open -a Mousecape "./husky-red-profile-v6/husky-red-profile-v6-48pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

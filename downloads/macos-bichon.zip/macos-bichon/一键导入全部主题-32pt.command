#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./bichon-photo-v3/bichon-photo-v3-32pt.cape"
open -a Mousecape "./bichon-cream-coral-v5/bichon-cream-coral-v5-32pt.cape"
open -a Mousecape "./bichon-ice-lilac-v5/bichon-ice-lilac-v5-32pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

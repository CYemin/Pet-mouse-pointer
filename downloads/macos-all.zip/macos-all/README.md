# macOS测试合集（10种、33款）

.command只导入，需先安装Mousecape，选一套Apply。Mac真机应用、Retina与多屏仍待测试。

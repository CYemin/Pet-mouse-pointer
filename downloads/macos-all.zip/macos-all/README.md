# 全部狗狗 Mousecape 合集（11种、37款）

先安装官方Mousecape，双击.command批量导入，再选一套Apply。全部主题包含ArrowS/IBeamS兼容项，2.0版、19个条目。重新导入旧同款前先恢复默认并移除旧同款，避免重复副本。已完成离线格式与像素检查；Mac真机、Retina、多屏待测。

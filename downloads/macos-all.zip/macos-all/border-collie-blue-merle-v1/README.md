# 边牧 · 蓝陨石 · macOS 测试版

需要先安装 [Mousecape](https://github.com/alexzielenski/Mousecape/releases)。本包不附带第三方程序。

1. 完整解压，双击 `border-collie-blue-merle-v1-32pt.cape` 导入 Mousecape。
2. 在 Mousecape 主题列表中选中导入的主题，使用 Apply 应用。大号请选择 `48pt.cape` 结尾的文件。
3. 恢复时使用 Mousecape 菜单 `Capes → Restore Defaults`；恢复后再删除本主题。
4. 打开 `preview.html` 检查转换后的动画和点击点，无需 Python。

包含13种对应动作、17个Mac指针条目，常规32pt和大号48pt，每种含1×/2×图像。32pt在Retina上使用64像素图像，48pt使用96像素图像；图像从同一基准帧缩放以保持热点一致。

Windows 的手写、候选、位置和人员选择没有直接对应条目，不导出。Mac额外的复制、别名、抓手、缩放等状态保留系统默认。具体App自绘指针可能不受主题影响。

Mousecape最多接受24个等时帧：能精确展开的停留保持原节奏，其余按时间采样到24帧，总循环时长保持一致，部分短促动作可能被简化。每个状态的转换记录见 `verification.json`。

**验证范围：** 已完成plist、PNG、帧顺序、尺寸、透明度、热点、时长与压缩包检查。当前制作环境为Windows，尚未在Mac导入或应用，不能承诺特定macOS版本、Intel/Apple Silicon、登录保持、多屏和Retina切换兼容性。Mac实测步骤见合集的 `macOS.md`。

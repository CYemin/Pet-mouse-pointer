@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title 应用小号鼠标（32px）
set "PET_CURSOR_DRY_RUN="
if /i "%~1"=="--check" set "PET_CURSOR_DRY_RUN=-WhatIf"
if not exist "%~dp0install-theme.ps1" (
  echo 找不到所需文件，请先完整解压主题包，再运行此入口。
  if not defined PET_CURSOR_DRY_RUN pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-theme.ps1" -Size 32 %PET_CURSOR_DRY_RUN%
set "PET_CURSOR_EXIT=%ERRORLEVEL%"
echo.
if "%PET_CURSOR_EXIT%"=="0" (
  if defined PET_CURSOR_DRY_RUN (
    echo 预演检查完成，没有修改系统鼠标设置。
  ) else (
    echo 应用小号鼠标（32px）成功。
  )
) else (
  echo 操作未完成。请保留上方的错误信息，以便排查。
)
echo.
if not defined PET_CURSOR_DRY_RUN pause
exit /b %PET_CURSOR_EXIT%

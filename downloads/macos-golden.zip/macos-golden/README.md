# macOS Mousecape 测试合集（4款）

先安装官方Mousecape，完整解压后双击`一键导入全部主题-32pt.command`（大号48pt）。也可双击各主题.cape逐一导入。随后在Mousecape选中一套、Apply；恢复使用Capes → Restore Defaults。脚本只导入，不自动应用或安装Mousecape。

导出格式及每个嵌入像素已验证；当前在Windows构建，Mac真机导入、应用、Retina和多屏均待测。详见macOS.md。

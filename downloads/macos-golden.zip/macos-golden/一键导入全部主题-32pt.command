#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./golden-cream-pixel/golden-cream-pixel-32pt.cape"
open -a Mousecape "./golden-standard-pixel/golden-standard-pixel-32pt.cape"
open -a Mousecape "./golden-light-pixel/golden-light-pixel-32pt.cape"
open -a Mousecape "./golden-dark-pixel/golden-dark-pixel-32pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! open -Ra Mousecape; then echo "Please install Mousecape first: https://github.com/alexzielenski/Mousecape/releases"; exit 1; fi
open -a Mousecape "./corgi-photo-v3/corgi-photo-v3-32pt.cape"
open -a Mousecape "./corgi-tricolor-v5/corgi-tricolor-v5-32pt.cape"
open -a Mousecape "./corgi-cream-v5/corgi-cream-v5-32pt.cape"
echo "Imported capes. Select one theme in Mousecape and Apply. Restore via Capes > Restore Defaults."

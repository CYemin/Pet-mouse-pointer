[CmdletBinding(SupportsShouldProcess)]
param([ValidateSet(32,48,64,96,128)][int]$Size = 48)
$ErrorActionPreference = 'Stop'
$manifestPath = Join-Path $PSScriptRoot 'manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$sourceFiles = @{}
foreach ($state in $manifest.states) {
    $relative = $state.variants.PSObject.Properties[[string]$Size].Value
    $source = Join-Path $PSScriptRoot $relative
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing cursor: $source" }
    $sourceFiles[$state.role] = $source
}
if (-not $PSCmdlet.ShouldProcess('Current user mouse pointer theme', "Install all 17 cursors at $Size px, with a restore backup")) { return }
$themeRoot = Join-Path $env:LOCALAPPDATA 'PetCursorThemes\Sable-Handdrawn'
$runId = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
$installPath = Join-Path $themeRoot $runId
New-Item -ItemType Directory -Path $installPath -Force | Out-Null
$key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Control Panel\Cursors', $true)
if ($null -eq $key) { throw 'Current user cursor registry key is unavailable' }
$records = @()
$names = @('') + @($manifest.states.role)
foreach ($name in $names) {
    $exists = $key.GetValueNames() -contains $name
    $records += [pscustomobject]@{ name=$name; exists=$exists; kind=$(if($exists){[string]$key.GetValueKind($name)}else{'String'}); value=$(if($exists){$key.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}else{$null}) }
}
$backup = [pscustomobject]@{version=1; created=(Get-Date).ToString('o'); records=$records}
$backupPath = Join-Path $installPath 'restore-backup.json'
$backup | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $backupPath -Encoding UTF8
try {
    foreach ($state in $manifest.states) {
        $source = $sourceFiles[$state.role]
        $target = Join-Path $installPath ([IO.Path]::GetFileName($source))
        Copy-Item -LiteralPath $source -Destination $target
        $key.SetValue($state.role,$target,[Microsoft.Win32.RegistryValueKind]::ExpandString)
    }
    $key.SetValue('',"Sable Handdrawn $Size",[Microsoft.Win32.RegistryValueKind]::String)
} catch {
    foreach ($record in $records) {
        if ($record.exists) { $kind=[Enum]::Parse([Microsoft.Win32.RegistryValueKind],[string]$record.kind); $key.SetValue($record.name,$record.value,$kind) }
        else { $key.DeleteValue($record.name,$false) }
    }
    throw
} finally { $key.Close() }
$refreshSource = @'
using System;
using System.Runtime.InteropServices;
public static class PetCursorRefresh {
 [DllImport("user32.dll",SetLastError=true)]
 public static extern bool SystemParametersInfo(uint action,uint parameter,IntPtr data,uint flags);
}
'@
if (-not ('PetCursorRefresh' -as [type])) { Add-Type -TypeDefinition $refreshSource }
if (-not [PetCursorRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,0)) { throw "Cursor refresh failed. Backup: $backupPath" }
$backupPath | Set-Content -LiteralPath (Join-Path $themeRoot 'latest-backup.txt') -Encoding UTF8
Write-Output "Applied $Size px theme. Restore backup: $backupPath"

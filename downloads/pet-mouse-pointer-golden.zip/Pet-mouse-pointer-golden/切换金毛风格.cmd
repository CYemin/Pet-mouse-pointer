@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title 切换金毛风格
echo.
echo   金毛风格（共 4 套）
echo   ----------------------------------
echo    1. 标准金毛
echo    2. 浅金毛
echo    3. 奶油白金毛
echo    4. 深金毛
echo   ----------------------------------
set "PICK="
set /p "PICK=输入编号后回车（直接回车取消）："
if not defined PICK goto cancel
echo %PICK%| findstr /r /c:"^[1-4]$" >nul || goto bad
echo.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-collection.ps1" -Collection golden -Index %PICK% -OpenPointerSettings
set "PET_CURSOR_EXIT=%ERRORLEVEL%"
echo.
if "%PET_CURSOR_EXIT%"=="0" (
  echo 切换完成，请查看刚打开的「鼠标属性 → 指针」。
) else (
  echo 切换未完成，请保留上方错误信息。
)
echo.
pause
exit /b %PET_CURSOR_EXIT%
:bad
echo 请输入 1 到 4 之间的编号。
timeout /t 3 >nul
exit /b 1
:cancel
echo 已取消，未修改任何设置。
timeout /t 2 >nul
exit /b 0

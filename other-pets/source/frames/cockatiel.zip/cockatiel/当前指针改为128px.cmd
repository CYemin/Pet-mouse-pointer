@echo off
setlocal DisableDelayedExpansion
ver | "%SystemRoot%\System32\find.exe" "6.1." >nul
if not errorlevel 1 goto pet_windows7
@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title 当前指针改为128px
set "PET_CURSOR_DRY_RUN="
if /i "%~1"=="--check" set "PET_CURSOR_DRY_RUN=-WhatIf"
if not exist "%~dp0resize-current.ps1" (
  echo 找不到所需文件，请先完整解压主题包，再运行此入口。
  if not defined PET_CURSOR_DRY_RUN pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-entry.ps1" -Script resize-current.ps1 -Size 128 %PET_CURSOR_DRY_RUN%
set "PET_CURSOR_EXIT=%ERRORLEVEL%"
echo.
if "%PET_CURSOR_EXIT%"=="0" (
  if defined PET_CURSOR_DRY_RUN (
    echo 预演检查完成，没有修改系统鼠标设置。
  ) else (
    echo 当前指针改为128px成功。
  )
) else (
  echo 操作未完成。请保留上方的错误信息，以便排查。
)
echo.
if not defined PET_CURSOR_DRY_RUN if not "%PET_CURSOR_EXIT%"=="0" pause
exit /b %PET_CURSOR_EXIT%

:pet_windows7
set "PET_WIN7_CHECK="
if /i "%~1"=="--check" set "PET_WIN7_CHECK=-WhatIf"
if not exist "%~dp0windows-entry.ps1" goto pet_win7_missing
if not exist "%~dp0windows7-theme.ps1" goto pet_win7_missing
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-entry.ps1" -Script resize-current.ps1 -Size 128 %PET_WIN7_CHECK%
set "PET_WIN7_EXIT=%ERRORLEVEL%"
if not "%PET_WIN7_EXIT%"=="0" (
  echo Pointer operation failed. Keep the error above for diagnosis.
  if not defined PET_WIN7_CHECK pause
)
exit /b %PET_WIN7_EXIT%

:pet_win7_missing
echo Missing compatibility files. Extract the complete updated package first.
if not defined PET_WIN7_CHECK pause
exit /b 1
